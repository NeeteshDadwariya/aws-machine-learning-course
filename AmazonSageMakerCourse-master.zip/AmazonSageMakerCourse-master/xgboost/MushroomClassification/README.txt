Mushroom Data Set 
https://archive.ics.uci.edu/ml/datasets/mushroom