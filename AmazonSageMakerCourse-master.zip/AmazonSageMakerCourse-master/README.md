Shield: [![CC BY-NC-SA 4.0][cc-by-nc-sa-shield]][cc-by-nc-sa]

This work is licensed under a
[Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License][cc-by-nc-sa].

[![CC BY-NC-SA 4.0][cc-by-nc-sa-image]][cc-by-nc-sa]

[cc-by-nc-sa]: http://creativecommons.org/licenses/by-nc-sa/4.0/
[cc-by-nc-sa-image]: https://licensebuttons.net/l/by-nc-sa/4.0/88x31.png
[cc-by-nc-sa-shield]: https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-lightgrey.svg
# AWS Certified Machine Learning Specialty (MLS-C01) Course
  
## To Enroll
https://www.udemy.com/course/aws-machine-learning-a-complete-guide-with-python/?referralCode=9ADB4395937F7D656EB9  
  
## What you will learn
Hi and Welcome to the AWS Certified Machine Learning Specialty (MLS-C01) Course  
  
I'm Chandra Lingam, and I'll be your instructor for this course. With over 100K students, I'm committed to staying current with the latest technologies and sharing my knowledge from the fundamentals up. I'm excited to have the opportunity to meet you and guide you through this course.
  
Here is what you will learn in this course:  
•	Gain first-hand experience on how to train, optimize, deploy, and integrate ML in AWS cloud  
•	AWS Built-in algorithms, Bring Your Own, Ready-to-use AI capabilities   
•	Complete Guide to AWS Certified Machine Learning – Specialty  
•	Includes a high-quality Timed practice test  (a lot of courses charge a separate fee for practice test)  
•	How to integrate the trained models in your application  
  
You will get prompt support through the course Q&A forum and private messaging  

I am looking forward to meeting you  

## To Enroll
https://www.udemy.com/course/aws-machine-learning-a-complete-guide-with-python/?referralCode=9ADB4395937F7D656EB9  
